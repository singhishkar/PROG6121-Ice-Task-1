/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package zooanimalcatalogue;

import java.util.Scanner;

/**
 *
 * @author ishka
 */
public class Animal {

    //Creating getters and setters to access private variables
    public int getIDtag() {
        return IDtag;
    }

    public void setIDtag(int IDtag) {
        this.IDtag = IDtag;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }
    
    //Declaring variables
    private int IDtag;
    private String species;
    
    //Input method
        public void input() {
        Scanner kb = new Scanner(System.in);
        Animal animal = new Animal();
        
        System.out.print("Enter ID tag: ");
        IDtag = kb.nextInt();  //Populating variable IDtag
        animal.setIDtag(IDtag);
        kb.nextLine();
        System.out.print("Enter species: ");
        species = kb.nextLine();   //Populating variable species
        animal.setSpecies(species);
    }

    //Output or Display method
        public void output() {
        System.out.println("ID tag: " + IDtag);
        System.out.println("Species: " + species);
    }

}
