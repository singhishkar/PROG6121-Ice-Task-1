/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package zooanimalcatalogue;

import java.util.Scanner;

/**
 *
 * @author ishka
 */
public class Bird extends Animal {

    //Creating getters and setters to access private variables
    public int getColour() {
        return colour;
    }

    public void setColour(int colour) {
        this.colour = colour;
    }
    
    //Declaring bird colour variable
    private int colour;
        
    @Override   //Creating an @Override method to use super.input and access methods and variables from "Animal"
    public void input() {
        super.input();  //'super.input()' carries over 'public void input ()' from 'Animal' and allows the addition of father
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter feather colour: "
                + "(1) for grey"
                + "(2) for white"
                + "(3) for black");
        colour = scanner.nextInt();
    }

    @Override   //Creating an @Override method to use super.input and access methods and variables from "Animal"
    public void output() {
        super.output();
        switch (colour) {
            case 1 -> System.out.println("Feather colour 1: grey");
            case 2 -> System.out.println("Feather colour 2: white");
            case 3 -> System.out.println("Feather colour 3: black");
        }
    }
 
}
